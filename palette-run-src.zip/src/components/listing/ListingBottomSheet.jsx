import { useState, useEffect } from 'react'
import { useListingStore } from '@/store/useListingStore'
import { useAuthStore }    from '@/store/useAuthStore'
import { supabase }        from '@/lib/supabase'
import { profitColor }     from '@/lib/mapbox'
import { formatPickupDeadline } from '@/lib/transaction'

const TIER_LIMIT = { free: 2, gold: Infinity }

// Ouvre l'adresse dans Google Maps ou Apple Maps
const openGPS = (address, lat, lng) => {
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
  const query = address ? encodeURIComponent(address) : `${lat},${lng}`
  if (isIOS) {
    window.open(`maps://maps.apple.com/?q=${query}&ll=${lat},${lng}`, '_blank')
  } else {
    window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank')
  }
}

// ─── Nouveau système d'enchère avec + / - ─────────────────────────────────────
function AuctionBidInput({ currentPrice, hasExistingBid, resalePrice, qty, bidding, bidResult, onBid }) {
  const minPrice = hasExistingBid
    ? Math.round((currentPrice + 0.50) * 10) / 10
    : currentPrice
  const [myBid, setMyBid] = useState(minPrice)

  const increment = () => setMyBid(p => Math.round((p + 0.50) * 10) / 10)
  const decrement = () => setMyBid(p => Math.max(minPrice, Math.round((p - 0.50) * 10) / 10))

  const profit = resalePrice ? (resalePrice - myBid) * qty : null
  const canBid = myBid > currentPrice

  return (
    <>
      {/* Prix actuel */}
      <div className="bg-pink/5 border border-pink/20 rounded-xl px-4 py-3 text-center">
        <p className="text-xs text-muted mb-1">Enchère actuelle</p>
        <p className="font-bebas text-3xl" style={{ color: "#EC4899" }}>{currentPrice.toFixed(2)} €</p>
      </div>

      {/* Sélecteur + / - */}
      <div className="bg-white border-2 border-border rounded-xl p-4">
        <p className="text-xs text-muted text-center mb-3">Votre enchère</p>
        <div className="flex items-center justify-between gap-4">
          <button onClick={decrement} disabled={myBid <= minPrice}
            className="w-12 h-12 rounded-xl border-2 font-bold text-xl cursor-pointer disabled:opacity-30 transition-colors"
            style={{ borderColor: "#EC4899", color: "#EC4899", background: "#EC489910" }}>
            −
          </button>
          <p className="font-bebas text-4xl text-gray-800 flex-1 text-center">{myBid.toFixed(2)} €</p>
          <button onClick={increment}
            className="w-12 h-12 rounded-xl border-2 font-bold text-xl cursor-pointer transition-colors"
            style={{ borderColor: "#EC4899", color: "#EC4899", background: "#EC489910" }}>
            +
          </button>
        </div>

        {/* Bénéfice potentiel */}
        {profit !== null && (
          <div className={`mt-3 rounded-lg px-3 py-2 text-center text-xs font-semibold ${profit > 0 ? "bg-green/10 text-green" : "bg-red/10 text-red"}`}>
            {profit > 0
              ? `📈 +${profit.toFixed(2)} € de bénéfice potentiel`
              : `📉 ${profit.toFixed(2)} € — vous perdriez de l'argent`}
          </div>
        )}
      </div>

      {/* Bouton enchérir */}
      <button onClick={() => onBid(Math.round((myBid - currentPrice) * 10) / 10)}
        disabled={bidding || !canBid}
        className="w-full py-4 rounded-2xl font-bold text-white text-base cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-opacity"
        style={{ background: canBid ? "linear-gradient(135deg,#EC4899,#db2777)" : "#D1D9E6", color: canBid ? "#fff" : "#94A3B8" }}>
        {bidding ? "Enchère en cours…" : canBid ? `⚡ Enchérir à ${myBid.toFixed(2)} €` : "Augmentez votre offre pour enchérir"}
      </button>

      {bidResult && (
        <div className={`w-full rounded-xl px-3 py-2 text-xs text-center font-semibold ${bidResult.success ? "bg-green/10 border border-green/30 text-green" : "bg-red/10 border border-red/30 text-red"}`}>
          {bidResult.success ? `✅ Enchère placée à ${bidResult.price.toFixed(2)} €` : "❌ Erreur — réessayez"}
        </div>
      )}
    </>
  )
}

export default function ListingBottomSheet({ listing, profile, onClose }) {
  const { reserveListing, placeBid, error: listingError } = useListingStore()
  const { user } = useAuthStore()
  const [booked,       setBooked]       = useState(false)
  const [bidding,      setBidding]      = useState(false)
  const [bidResult,    setBidResult]    = useState(null) // { success, price }
  const [isConfirmed,   setIsConfirmed]   = useState(false)
  const [isAuthorized,  setIsAuthorized]  = useState(false)
  const [companyDetails, setCompanyDetails] = useState(null) // { name, address, lat, lng }

  // Vérifie si transaction confirmée et charge les détails défloutés via fonction SQL sécurisée
  useEffect(() => {
    if (!user?.id || !listing?.id) return
    supabase
      .from('transactions')
      .select('id')
      .eq('listing_id', listing.id)
      .eq('driver_id', user.id)
      .eq('status', 'confirmed')
      .maybeSingle()
      .then(async ({ data }) => {
        const confirmed = !!data
        setIsConfirmed(confirmed)
        if (confirmed) {
          // Récupère name + address uniquement si transaction confirmée
          const { data: details } = await supabase
            .rpc('get_confirmed_company_details', { p_listing_id: listing.id })
          if (details?.[0]) setCompanyDetails(details[0])
        }
      })
  }, [listing?.id, user?.id])

  // Realtime sur transactions — met à jour isConfirmed si le commerçant valide
  useEffect(() => {
    if (!user?.id || !listing?.id) return
    const sub = supabase
      .channel(`listing-tx-${listing.id}`)
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'transactions'
      }, async (payload) => {
        if (payload.new?.listing_id !== listing.id && payload.old?.listing_id !== listing.id) return
        const { data } = await supabase
          .from('transactions')
          .select('id, status')
          .eq('listing_id', listing.id)
          .eq('driver_id', user.id)
          .in('status', ['authorized', 'confirmed'])
          .maybeSingle()
        if (data) {
          setIsConfirmed(data.status === 'confirmed')
          setIsAuthorized(data.status === 'authorized')
          if (data.status === 'authorized' || data.status === 'confirmed') {
            const { data: details } = await supabase
              .rpc('get_confirmed_company_details', { p_listing_id: listing.id })
            if (details?.[0]) setCompanyDetails(details[0])
          }
        }
      })
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [listing?.id, user?.id])

  const userTier       = profile?.tier          || 'free'
  const resalePrice    = profile?.resale_price  || null
  const goldThreshold  = profile?.gold_threshold || 20
  const canBook        = userTier === 'gold'
  const isHidden       = listing.qty > (TIER_LIMIT[userTier] || 2)
  const isReserved     = listing.reserved_by !== null
  const isReservedByMe = listing.reserved_by === user?.id
  const color          = isHidden ? '#4A5568' : profitColor(listing.price, resalePrice, goldThreshold, listing.qty)

  // Nom et adresse visibles uniquement si le commerçant a validé la transaction
  // En mode enchère : le chauffeur voit les détails s'il est le meilleur enchérisseur
  // En mode normal : seulement si la transaction est confirmée
  const isAuctionMode = listing?.auction_mode === true
  const isTopBidder   = isAuctionMode && listing?.reserved_by === user?.id
  const canSeeDetails = isConfirmed || isAuthorized || isTopBidder

  const currentPrice = listing.current_bid || listing.price

  const profit = resalePrice && resalePrice > listing.price && !isHidden
    ? (resalePrice - currentPrice) * listing.qty
    : null

  const handleReserve = async () => {
    setBooked(true)
    const ok = await reserveListing(listing.id)
    if (!ok) {
      setBooked(false)
      // L'erreur est dans le store, on ferme après 2s pour que l'utilisateur la voie
      setTimeout(onClose, 2500)
    } else {
      setTimeout(onClose, 1000)
    }
  }

  const handleBid = async (step) => {
    setBidding(true)
    setBidResult(null)
    const ok = await placeBid(listing.id, step, currentPrice, null)
    setBidding(false)
    if (ok) {
      setBidResult({ success: true, price: parseFloat((currentPrice + step).toFixed(2)) })
      setTimeout(() => setBidResult(null), 3000)
    } else {
      setBidResult({ success: false })
      setTimeout(() => setBidResult(null), 3000)
    }
  }

  return (
    <>
      {/* Overlay */}
      <div className="absolute inset-0 z-30 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      {/* Sheet */}
      <div className="absolute bottom-0 left-0 right-0 z-40 bg-surface rounded-t-3xl border border-border border-b-0 shadow-2xl"
        style={{ animation: 'slideUp 0.3s cubic-bezier(0.34,1.2,0.64,1)' }}
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-9 h-1 rounded-full bg-border" />
        </div>

        <div className="px-5 pb-8">
          {/* Header */}
          <div className="flex items-start gap-2 mb-4">
            <div className="flex-1">
              {/* Nom flou avant réservation */}
              <h2 className="font-bebas text-2xl leading-tight"
                style={{ color: isHidden ? '#4A5568' : '#E8EDF5' }}>
                {isHidden
                  ? 'Nom masqué'
                  : canSeeDetails
                    ? (companyDetails?.name || 'Vendeur')
                    : <span style={{ filter: 'blur(6px)', userSelect: 'none' }}>Vendeur</span>
                }
              </h2>
              <p className="text-sub text-sm mt-0.5">
                {isHidden
                  ? '—'
                  : canSeeDetails
                    ? listing.companies?.city
                    : <span style={{ filter: 'blur(5px)', userSelect: 'none' }}>Ville</span>
                }
                {canSeeDetails && companyDetails?.address && (
                  <span className="block text-xs text-muted mt-0.5">📍 {companyDetails.address}</span>
                )}
                {!canSeeDetails && !isHidden && (
                  <span className="block text-xs text-muted/50 mt-0.5 italic">
                    {isReservedByMe ? 'En attente de validation du commerçant…' : 'Adresse visible après validation'}
                  </span>
                )}
              </p>
            </div>
            <button onClick={onClose}
              className="w-9 h-9 rounded-xl bg-hi border border-border flex items-center justify-center text-xl text-sub">×</button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            {[
              { label: 'Palettes',   value: (isReserved && !isAuctionMode) ? '—' : listing.qty,                                                   color },
              { label: 'Prix',       value: (isReserved && !isAuctionMode) ? '—' : `${currentPrice.toFixed(2)}€`,                      color: '#2ECC71' },
              { label: 'Total',      value: (isReserved && !isAuctionMode) ? '—' : `${(listing.qty * currentPrice).toFixed(2)}€`,      color: '#F5A623' },
            ].map(s => (
              <div key={s.label} className="bg-hi rounded-2xl p-3 text-center border border-border">
                <p className="font-bebas text-2xl leading-none" style={{ color: isReserved ? '#4A5568' : s.color }}>
                  {s.value}
                </p>
                <p className="text-[10px] text-muted mt-1">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Profit badge */}
          {profit !== null && (
            <div className="flex items-center gap-2 mb-4 rounded-xl px-3 py-2.5"
              style={{ background: `${color}18`, border: `1px solid ${color}33` }}>
              <span className="text-lg">📈</span>
              <div>
                <span className="font-bebas text-xl" style={{ color }}>
                  {profit >= 0 ? '+' : ''}{profit.toFixed(2)} €
                </span>
                <span className="text-sub text-xs ml-2">bénéfice potentiel</span>
              </div>
            </div>
          )}

          {/* Heure limite */}
          {listing.pickup_before && !isReserved && (
            <div className="flex items-center gap-2 mb-4 bg-blue/10 border border-blue/30 rounded-xl px-3 py-2">
              <span>🕐</span>
              <p className="text-blue text-sm">
                Récupérer avant <strong>{listing.pickup_before.slice(0, 5)}</strong>
              </p>
            </div>
          )}

          {/* Enchère programmée */}
          {listing.auction_mode && listing.auction_ends_at && (
            <div className="mb-4">
              <AuctionCountdown endsAt={listing.auction_ends_at} daysOnly={true} />
              <p className="text-xs text-muted text-center mt-2">
                Le gagnant aura 7 jours pour venir récupérer les palettes.
              </p>
            </div>
          )}

          {/* Délai d'enlèvement selon quantité */}
          {!isReserved && !isHidden && (
            <div className="flex items-center gap-2 mb-4 bg-surface border border-border rounded-xl px-3 py-2">
              <span>📅</span>
              <div>
                <p className="text-gray-800 text-sm font-semibold">
                  Enlèvement au plus tard : <strong className="text-amber">{formatPickupDeadline(listing.qty)}</strong>
                </p>
                <p className="text-muted text-xs mt-0.5">
                  {listing.qty < 15
                    ? 'Moins de 15 palettes — enlèvement aujourd\'hui'
                    : `${listing.qty} palettes — ${Math.min(Math.floor(listing.qty / 15), 4)} jour(s) ouvrés accordés`}
                </p>
              </div>
            </div>
          )}

          {/* Tier nudge */}
          {isHidden && (
            <div className="mb-4 rounded-xl px-4 py-3"
              style={{ background: userTier === 'free' ? '#F5A62318' : '#FFD16618', border: `1px solid ${userTier === 'free' ? '#F5A62333' : '#FFD16633'}` }}>
              <p className="text-sm font-semibold" style={{ color: userTier === 'free' ? '#F5A623' : '#FFD166' }}>
                🔒 {userTier === 'free' ? 'Annonce > 2 palettes — passez Gold' : 'Annonce > 10 palettes — réservé Gold'}
              </p>
            </div>
          )}

          {/* CTA */}
          <div className="flex flex-col gap-2">
            {isHidden ? (
              <>
                {userTier === 'free' && (
                  <button className="w-full py-4 rounded-2xl font-bold text-bg"
                    style={{ background: 'linear-gradient(135deg,#F5A623,#E8940F)', boxShadow: '0 6px 20px rgba(245,166,35,0.4)' }}>
                    ⭐ Gold — 24,90€/mois
                  </button>
                )}
                <button className="w-full py-3 rounded-2xl font-bold border text-gold"
                  style={{ borderColor: '#FFD16666', background: '#FFD16618' }}>
                  🥇 Gold — 24,90€/mois
                </button>
              </>
            ) : isReserved ? (
              <div className="w-full py-4 rounded-2xl bg-hi border border-border text-center text-muted text-sm">
                Disponible dès qu'elle est libérée
              </div>
            ) : canBook ? (
              <>
                {!booked ? (
                  <>
                    {listing.auction_mode ? (
                      /* Mode enchère — champ libre avec minimum +0.50€ et pas de 0.10€ */
                      <AuctionBidInput
                        currentPrice={currentPrice}
                        hasExistingBid={listing?.current_bid !== null && listing?.current_bid !== undefined}
                        resalePrice={resalePrice}
                        qty={listing?.qty}
                        bidding={bidding}
                        bidResult={bidResult}
                        onBid={handleBid}
                      />
                    ) : (
                      /* Mode réservation directe */
                      <>
                        <div className="bg-amber/10 border border-amber/30 rounded-xl px-4 py-3 mb-1">
                          <p className="text-amber text-xs leading-relaxed">
                            ⚠️ En réservant, vous vous engagez à venir récupérer ces palettes <strong>aujourd'hui</strong>. Les no-shows répétés entraînent une suspension de votre compte.
                          </p>
                        </div>
                        {listingError && (
                          <div className="w-full rounded-xl bg-red/10 border border-red/30 px-3 py-2 text-red text-xs text-center mb-2">
                            ⚠️ {listingError}
                          </div>
                        )}
                        <button onClick={handleReserve}
                          className="w-full py-4 rounded-2xl font-bold text-bg cursor-pointer"
                          style={{ background: 'linear-gradient(135deg,#FFD166,#E8B800)', boxShadow: '0 6px 20px rgba(255,209,102,0.4)' }}>
                          🥇 Réserver ces palettes
                        </button>
                      </>
                    )}
                  </>
                ) : (
                  <div className="w-full py-4 rounded-2xl font-bold text-center text-green bg-green/10 border border-green/30">
                    ✅ Réservée !
                  </div>
                )}
              </>
            ) : (
              <>
                {canSeeDetails ? (
                  <>
                    <div className="w-full py-4 rounded-2xl bg-green/10 border border-green/30 text-center text-green text-sm font-semibold">
                      ✅ Rendez-vous directement en vendeur
                    </div>
                    <button onClick={() => openGPS(
                      companyDetails?.address,
                      companyDetails?.lat,
                      companyDetails?.lng
                    )}
                      className="w-full py-3 rounded-2xl border border-border bg-hi text-white text-sm font-semibold cursor-pointer flex items-center justify-center gap-2">
                      🗺 Y aller
                    </button>
                  </>
                ) : (
                  <div className="w-full py-4 rounded-2xl bg-hi border border-border text-center text-muted text-sm">
                    {isReservedByMe
                      ? '⏳ En attente de validation du commerçant…'
                      : '🔒 Adresse visible après validation'}
                  </div>
                )}
                <button className="w-full py-3 rounded-2xl border font-bold text-gold text-sm"
                  style={{ borderColor: '#FFD16666', background: '#FFD16618' }}>
                  🥇 Gold — réserver en priorité
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideUp { from { transform: translateY(100%) } to { transform: translateY(0) } }
      `}</style>
    </>
  )
}
